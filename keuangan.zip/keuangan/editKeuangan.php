<?php
require 'koneksi.php';
$input = file_get_contents('php://input');
$data = json_decode($input,true);

$id=trim($data['id']);
$jenis=trim($data['jenis']);
$note=trim($data['note']);
$jumlah=trim($data['jumlah']);
http_response_code(201);
if($jenis!='' and $note!='' and $jumlah!=''){
$query = mysqli_query($koneksi,"update keuangan set jenis='$jenis',note='$note', jumlah='$jumlah' where
id='$id'");
$pesan = true;
}else{
$pesan = false;
}
echo json_encode($pesan);
echo mysqli_error($koneksi);